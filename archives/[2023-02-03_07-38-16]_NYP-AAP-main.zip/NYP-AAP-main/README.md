# NYP-AAP
 AAP Project

```bash
# First setup after clone
sudo apt install python3-venv
python -m venv venv

# Enter venv & install packages (the .txt file exists already)
source ./venv/bin/activate
pip install -r requirements.txt
```

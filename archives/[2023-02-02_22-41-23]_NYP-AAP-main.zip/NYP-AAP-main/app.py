from flask import Flask, render_template
from routes import app
from uuid import uuid4, UUID
import secrets, string, os, getpass

if (__name__ == '__main__'):
	app.run(host='0.0.0.0', port=8080)
	app.logger.info('its time to get funky')

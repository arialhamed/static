from flask import Flask, render_template
from routes import app
from uuid import uuid4, UUID
import secrets, string, os, getpass, sys

if (__name__ == '__main__'):
	if len(sys.argv) > 1 and sys.argv[1] == "ngrok":
		os.system(f"ngrok authtoken {getpass.getpass('Paste ngrok authtoken: ')}")
		from flask_ngrok import run_with_ngrok
		run_with_ngrok(app)
		app.run()
	else:
		app.run(host='0.0.0.0', port=8080)
		app.logger.info('its time to get funky')

# Main Python File for Application(Website)

# from routes.{python-file} import {variable}
# Import routes here
from routes.predict import predict
from routes.predict_price import predict_price
from routes.estimate import estimate 
from routes.contact import contact
from uuid import UUID
import os, json, time, datetime, shelve, uuid, mimetypes, requests
from flask import Flask, render_template, url_for, session, after_this_request, request, abort, redirect
mimetypes.add_type('application/javascript', '.js')
localpath = os.getcwd()
app = Flask(
    "astralrealestate", 
    template_folder= f"{os.getcwd()}/templates", 
    static_folder=f"{os.getcwd()}/static"
)

from routes.news import news, retrieve_func

sgtemp = f"{round(sum([x['value'] for x in json.loads(requests.get('https://api.data.gov.sg/v1/environment/air-temperature').text)['items'][0]['readings']])/4,1)}°C, Singapore"

# Note just change the secret key by abit to clear all session contents
app.config["SECRET_KEY"] = "mysuperdupersecrethash365tothepowerof369andadditionosfthesecretmatrix420keanureevesss"

# Produict image validations
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024
app.config['UPLOAD_EXTENSIONS'] = ['.jpg', '.png', '.gif']
app.config['UPLOADED_SHOP_DEST'] = os.path.join(localpath, 'static/shop')

# Register blueprint for your routes
app.register_blueprint(predict, url_prefix="/predict")
app.register_blueprint(predict_price, url_prefix="/predict_price")
app.register_blueprint(estimate, url_prefix="/estimate")
app.register_blueprint(news, url_prefix="/news")
app.register_blueprint(contact, url_prefix="/contact")

@app.route("/", methods=["GET"])
def home():
    newsload = retrieve_func(limit=4)
    flashnews_data = newsload.pop(0)
    return render_template("home.html", sgtemp=sgtemp, newsload=newsload, flashnews_data=flashnews_data)

# @app.route("/news", methods=["GET", "POST"])
# def news():
#     return render_template("news.html")
import uuid, re, os, json, requests
from flask import Blueprint, render_template, request, redirect, url_for, abort, flash, send_from_directory, escape
from flask_wtf import FlaskForm
from routes.news import retrieve_func
from wtforms import StringField, TextAreaField, validators, FileField, IntegerField, SelectField, SubmitField
from wtforms.validators import InputRequired
#from werkzeug.utils import secure_filename
#from flask_uploads import configure_uploads, IMAGES, UploadSet

contact = Blueprint("contact", __name__, static_folder=os.path.join(
    os.getcwd(), "static"), template_folder=os.path.join(os.getcwd(), "templates"))
sgtemp = round(sum([x['value'] for x in json.loads(requests.get('https://api.data.gov.sg/v1/environment/air-temperature').text)['items'][0]['readings']])/4,1)

localpath = os.getcwd()

class productForm(FlaskForm):
    '''
    Form object for database.
    '''
    #FileField('images', validators=[FileRequired()])
    image = FileField('images', validators=[InputRequired()])
    name = StringField('Product Name', [validators.Length(min=1, max=30)])
    category = SelectField('Category', choices=[('Neckwear', 'Neckwear'), ('Earwear', 'Earwear'), ('Handwear', 'Handwear')], default='Neckwear')
    description = TextAreaField(
        u'Description', [validators.optional(), validators.length(max=200)])
    quantity = IntegerField(
        'Quantity', [validators.NumberRange(min=1, max=999)])
    price = IntegerField('Price (In Cents)', [
                         validators.NumberRange(min=1, max=9999999)])
    addSubmit = SubmitField('Submit')

class quantityForm(FlaskForm):
    '''
    Quanity Form object for database
    '''
    quantity = IntegerField(
        'Quantity', [validators.NumberRange(min=1, max=99999)])

class imageForm(FlaskForm):
    '''
    Image form object for database
    '''
    image = FileField('images')

@contact.route('/', methods=['GET', 'POST'])
def submit_contact():
    '''
    Main Page
    '''

    form = quantityForm()
    #statTable = update_db()
    #products = displayProduct(statTable["restockMinimum"])

    return render_template('home.html', sgtemp=sgtemp, flashnews_data=retrieve_func(limit=1))


import uuid, json, requests, os, re
from flask import Blueprint, render_template, request, redirect, url_for, abort, flash, send_from_directory, escape, jsonify
import pandas as pd
import sentencepiece as spm
from keras.models import load_model
from keras_preprocessing.sequence import pad_sequences
import shelve
from datetime import date
from bs4 import BeautifulSoup
from urllib.request import urlopen
from random import randint

news = Blueprint("news", __name__, static_folder=os.path.join(
    os.getcwd(), "static"), template_folder=os.path.join(os.getcwd(), "templates"))

# Loading model & tokenizer. 
model = load_model(os.path.join(os.getcwd(), "static/model/news/stpc.h5"), compile=False)
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['acc'])
sp = spm.SentencePieceProcessor()
sp.load(os.path.join(os.getcwd(), "static/model/news/bpe.model"))
print("SentencePiece: Found %s unique tokens." % sp.get_piece_size())

def refresh_news_func():
    df = pd.DataFrame()
    total_sitemap_pages = 35
    url = "https://www.straitstimes.com/sitemap.xml?page="+str(total_sitemap_pages+1)
    html = urlopen(url)
    soup = BeautifulSoup(html, 'lxml')
    soup_as_text = soup.get_text().split('\n')
    soup_url = [x for x in soup_as_text if "https://" in x]
    soup_datetime = [x for x in soup_as_text if "+08:00" in x]
    soup_headline = [x.split('/',3)[-1].replace('-', ' ').replace('/', ' ') for x in soup_as_text if "https://" in x]
    df = pd.concat([df, pd.DataFrame(
        {"url": soup_url, "datetime": soup_datetime, "headline": soup_headline}
    )], ignore_index=True)
    df.sort_values("datetime", ignore_index=True, ascending=False, inplace=True)
    for dropkey in ["authors", "node", "container"]:
        df.drop(df[df["url"].str.contains(dropkey)].index, inplace=True)
    df.drop(df[df["url"].str.count("/")<=3].index, inplace=True)
    df.to_csv(os.path.join(os.getcwd(), "static/stdb.csv"))
    # return os.path.join(os.getcwd(), "static/stdb.csv")
    return "/static/stdb.csv"

if not(os.path.isfile(os.path.join(os.getcwd(), "static/stdb.csv"))):
    refresh_news_func()
lookup = pd.read_csv(os.path.join(os.getcwd(), "static/stdb.csv"))

# News page is programmed for efficiency. It will do these 3 things every 24 hours
# - refresh stdb.csv to get latest news
# - predict latest news that are related to housing
# - add new row to newsdb
# and from there on for the rest of the day the page will load from the existing newsdb
@news.route('/', methods=['GET','POST'], defaults={'specdate': str(date.today())})
@news.route('/<specdate>')
def render_news(specdate):
    sgtemp = f"{round(sum([x['value'] for x in json.loads(requests.get('https://api.data.gov.sg/v1/environment/air-temperature').text)['items'][0]['readings']])/4,1)}°C, Singapore"

    # for now it is still hard to implement asynchronous loading
    newsload = retrieve_func(specdate)
    print(newsload)
    flashnews_data = newsload.pop(0)
    newsa, newsb, newsc = newsload[:6], newsload[6:9], newsload[9:13]
    return render_template('news.html', sgtemp=sgtemp, newsa=newsa, newsb=newsb, newsc=newsc, flashnews_data=flashnews_data)

# This is an API right here
@news.route('/classify/<sentence>', methods=['GET','POST'])
def classify_news(sentence):
    return retrieve_classification(sentence)

# Singular use thing
def retrieve_classification(sentence):
    input_sent = sentence.split('/',3)[-1].replace('-', ' ').replace('/', ' ') if "straitstimes.com" in sentence else sentence.replace('-',' ')
    isHousing = str(model.predict(pad_sequences([sp.encode_as_ids(input_sent)], maxlen=16))[:, 1][0])
    return {"sentence":input_sent,"isHousing":isHousing}

# API to manually refresh news and get static link
@news.route('/refresh-news', methods=['GET'])
def refresh_news():
    return f"{request.base_url[:-1].rsplit('/',2)[0]}{refresh_news_func()}"

# If you request an invalid or unavailable specdate, it will just get the news for today
@news.route('/retrieve-news', methods=['GET','POST'], defaults={'specdate': str(date.today())})
@news.route('/retrieve-news/<specdate>')
def retrieve_news(specdate):
    return jsonify(retrieve_func(specdate)) 

# get news for usage, used by a lot of modules in this system
def retrieve_func(specdate=str(date.today()),limit=13):
    cur_date = str(date.today())
    outload = []
    counter = 0
    with shelve.open(os.path.join(os.getcwd(), "static/newsdb"), 'c') as db:
        print(f"NewsDB data for {cur_date} ", end="")
        if specdate != cur_date and specdate in db:
            print("is ignored, specified date is requested.")
            outload = db[specdate]
        else:
            if cur_date in db:
                print("exists, reading from it now.")
                outload = db[cur_date]
            else:
                refresh_news_func()
                print("doesn't exist, creating new records now.")
                # for n, i in enumerate(model.predict(pad_sequences([sp.encode_as_ids(str(text)) for text in lookup["headline"].tolist()], maxlen=16))[:, 1]):
                for n, i in enumerate(lookup["headline"].tolist()):
                    if counter >= 20:
                        break
                    if retrieve_classification(i)["isHousing"] > .75:
                        counter += 1
                        outload.append([
                            lookup["url"].tolist()[n], 
                            ' '.join([x.capitalize() for x in i.split(' ')]), 
                            str(randint(0,9))
                        ])
                db[cur_date] = outload
    print(outload)
    return outload[:limit] if limit > 1 else outload[0]



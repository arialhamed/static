def updateSTDB():
	import pandas as pd
	from bs4 import BeautifulSoup
	from urllib.request import urlopen
	import os
	# os.system("rm -rf "+os.path.join(os.getcwd(), 'static/stdb.csv'))

	# This script is meant to be only ran once

	df = pd.DataFrame()
	total_sitemap_pages = 35

	# for i in range(total_sitemap_pages):
		# assert i == 0 # for debugging
	url = "https://www.straitstimes.com/sitemap.xml?page="+str(total_sitemap_pages+1)
	html = urlopen(url)

	# note that using 'lxml' may not be available if you're running this notebook
	# on a local runtime, which i would not recommend imo
	soup = BeautifulSoup(html, 'lxml')
	soup_as_text = soup.get_text().split('\n')
	soup_url = [x for x in soup_as_text if "https://" in x]
	soup_datetime = [x for x in soup_as_text if "+08:00" in x]
	soup_headline = [x.split('/',3)[-1].replace('-', ' ').replace('/', ' ') for x in soup_as_text if "https://" in x]

	# keep on appending to df
	df = pd.concat([df, pd.DataFrame(
		{"url": soup_url, "datetime": soup_datetime, "headline": soup_headline}
	)], ignore_index=True)

	df.sort_values("datetime", ignore_index=True, ascending=False, inplace=True)
	for dropkey in ["authors", "node", "container"]:
		df.drop(df[df["url"].str.contains(dropkey)].index, inplace=True)
	df.drop(df[df["url"].str.count("/")<=3].index, inplace=True)
	# df[["category","headline"]] = df["url"].str.slice(29,).str.rsplit('/',1,expand=True)

	# backup to hosted runtime
	df.to_csv(os.path.join(os.getcwd(), "static/stdb.csv"))

if (__name__ == '__main__'):
	updateSTDB()
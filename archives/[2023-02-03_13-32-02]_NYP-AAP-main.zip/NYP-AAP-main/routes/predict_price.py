import uuid, os, re, json, requests
from flask import Blueprint, render_template, request, redirect, url_for, abort, flash, send_from_directory, escape, jsonify
from flask_wtf import FlaskForm
from routes.news import retrieve_func
from wtforms import StringField, TextAreaField, validators, FileField, IntegerField, SelectField, SubmitField
from wtforms.validators import InputRequired
#from werkzeug.utils import secure_filename
#from flask_uploads import configure_uploads, IMAGES, UploadSet
# from tensorflow import keras 
from keras.models import load_model
import numpy as np
import matplotlib.pyplot as plt
from keras.models import model_from_json
from keras.utils import plot_model
# import tensorflow as tf



predict_price = Blueprint("predict_price", __name__, static_folder=os.path.join(
    os.getcwd(), "static"), template_folder=os.path.join(os.getcwd(), "templates"))
#sgtemp = round(sum([x['value'] for x in json.loads(requests.get('https://api.data.gov.sg/v1/environment/air-temperature').text)['items'][0]['readings']])/4,1)

localpath = os.getcwd()
# Load the model architecture from a JSON file
with open('static/model/predict_price/model.json', "r") as json_file:
    json_savedModel = json_file.read()

# Loading the model architecture, weights
model = model_from_json(json_savedModel)
model.load_weights('static/model/predict_price/model.h5')

@predict_price.route('/', methods=['GET'])
def render_predict_price():
    '''
    Main Page
    '''

#    form = quantityForm()
    #statTable = update_db()
    #products = displayProduct(statTable["restockMinimum"])

    return render_template('predict_price.html', flashnews_data=retrieve_func(limit=1))


@predict_price.route('/', methods=['POST'])
def predict_prices():

    # Get input data from the request
    input_data = request.get_json()['input']

    # Make a prediction
    prediction = model.predict(np.array(input_data))

    # Return the prediction as a response
    return jsonify({'prediction': prediction.tolist()})

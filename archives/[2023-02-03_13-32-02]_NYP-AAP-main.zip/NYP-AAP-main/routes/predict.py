import uuid, os, re, requests, json
import joblib
from routes.news import retrieve_func
from flask import Blueprint, render_template, request, redirect, url_for, abort, flash, send_from_directory, escape
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, validators, FileField, IntegerField, SelectField, SubmitField, DateField
from wtforms.validators import InputRequired
# Import pandas library
import pandas as pd
#from werkzeug.utils import secure_filename
#from flask_uploads import configure_uploads, IMAGES, UploadSet

predict = Blueprint("predict", __name__, static_folder=os.path.join(
    os.getcwd(), "static"), template_folder=os.path.join(os.getcwd(), "templates"))

localpath = os.getcwd()

# Load Model
model = joblib.load(f"{os.getcwd()}/static/model/jenson/RFR.pkl") 
print ("Model loaded")
rnd_columns = joblib.load(f"{os.getcwd()}/static/model/jenson/rnd_columns.pkl") # Load “rnd_columns.pkl”
print ("Model columns loaded")

class predictForm(FlaskForm):
    '''
    Form object for database.
    '''
    flat_model = SelectField('Flat Model', choices=[('Improved', 'Improved'), ('New Generation', 'New Generation'), ('Standard', 'Standard'), ('DBSS', 'DBSS'), ('Apartment', 'Apartment'), ('Premium Apartment', 'Premium Apartment'), ('Maisonette', 'Maisonette'), ('Terrace', 'Terrace'), ('Multi Generation', 'Multi Generation')], default='')
    flat_type = SelectField('Flat Type', choices=[('1 ROOM', '1 ROOM'), ('2 ROOM', '2 ROOM'), ('3 ROOM', '3 ROOM'), ('4 ROOM', '4 ROOM'), ('5 ROOM', '5 ROOM'), ('EXECUTIVE', 'EXECUTIVE')], default='')
    floor_area_sqm = IntegerField(
        'Floor Area SQM', [validators.NumberRange(min=1, max=999)])
    month = DateField('month', format='%Y-%m')
    remaining_lease = IntegerField(
        'Remaining Lease in number of month', [validators.NumberRange(min=1, max=999)])
    storey_range1 = IntegerField(
        'Storey range 1', [validators.NumberRange(min=1, max=99)])
    storey_range2 = IntegerField(
        'Storey range 2', [validators.NumberRange(min=1, max=99)])
    town = SelectField('Town', choices=[('ANG MO KIO', 'ANG MO KIO'), ('BEDOK', 'BEDOK'), ('BISHAN', 'BISHAN'), ('BUKIT BATOK', 'BUKIT BATOK'), ('BUKIT MERAH', 'BUKIT MERAH'), ('BUKIT PANJANG', 'BUKIT PANJANG'), ('BUKIT TIMAH', 'BUKIT TIMAH'), ('CHOA CHU KANG', 'CHOA CHU KANG'), ('CLEMENTI', 'CLEMENTI'), ('GEYLANG', 'GEYLANG'), ('JURONG EAST', 'JURONG EAST'), ('JURONG WEST', 'JURONG WEST'), ('KALLANG/WHAMPOA', 'KALLANG/WHAMPOA'), ('MARINE PARADE', 'MARINE PARADE'), ('PASIR RIS', 'PASIR RIS'), ('PUNGGOL', 'PUNGGOL'), ('QUEENSTOWN', 'QUEENSTOWN'), ('SEMBAWANG', 'SEMBAWANG'), ('SENGKANG', 'SENGKANG'), ('SERANGOON', 'SERANGOON'), ('TAMPINES', 'TAMPINES'), ('TOA PAYOH', 'TOA PAYOH'), ('WOODLANDS', 'WOODLANDS'), ('YISHUN', 'YISHUN'), ('CENTRAL AREA', 'CENTRAL AREA')], default='')
    mrt_distance = IntegerField(
        'MRT Distance', [validators.NumberRange(min=1, max=99999)])
    addSubmit = SubmitField('Submit')

@predict.route('/', methods=['GET', 'POST'])
def make_predict():
    '''
    Main Page
    '''

    form = predictForm()
    #statTable = update_db()
    #products = displayProduct(statTable["restockMinimum"])



    #joblib.load(f"{os.getcwd()}/static/model/jenson/RFR.joblib")

    if request.method == 'POST':
        #storey_range = form.storey_range1.data + "TO" + form.storey_range2.data
        #df = pd.DataFrame([form.flat_type.data, form.floor_area_sqm.data, form.month.data, form.remaining_lease.data, form.resale_price, form.town.data])
        df = pd.read_csv(f"{os.getcwd()}/static/dataset/x_test.csv")
        df = df.drop("Unnamed: 0", axis=1)
        print("predicting")
        print(model.predict(df.values[:1]))
        result = model.predict(df.values[:1])

        return result


    return render_template('predict.html', form=form)


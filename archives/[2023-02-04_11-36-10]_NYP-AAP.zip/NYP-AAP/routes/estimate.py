import uuid, os, re, json, requests
from flask import Blueprint, render_template, request, redirect, url_for, abort, flash, send_from_directory, escape
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, validators, FileField, IntegerField, SelectField, SubmitField
from wtforms.validators import InputRequired
from routes.news import retrieve_func
#from werkzeug.utils import secure_filename
#from flask_uploads import configure_uploads, IMAGES, UploadSet

estimate = Blueprint("estimate", __name__, static_folder=os.path.join(
    os.getcwd(), "static"), template_folder=os.path.join(os.getcwd(), "templates"))
sgtemp = round(sum([x['value'] for x in json.loads(requests.get('https://api.data.gov.sg/v1/environment/air-temperature').text)['items'][0]['readings']])/4,1)

localpath = os.getcwd()

@estimate.route('/', methods=['GET'])
def render_estimate():
    '''
    Main Page
    '''

#    form = quantityForm()
    #statTable = update_db()
    #products = displayProduct(statTable["restockMinimum"])

    return render_template('estimate.html', sgtemp=sgtemp, flashnews_data=retrieve_func(limit=1))

